# Express API Server

## Description
This is a simple Express API server with a single endpoint.

## Setup
1. Install dependencies:
   ```
   npm install
   ```
2. Start the server:
   ```
   npm start
   ```

## Endpoint
- `GET /users` - Returns a list of users.
